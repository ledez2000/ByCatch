###### Class kotlinx.coroutines.android.AndroidDispatcherFactory (kotlinx.coroutines.android.AndroidDispatcherFactory)
.class public final Lkotlinx/coroutines/android/AndroidDispatcherFactory;
.super Ljava/lang/Object;
.source "HandlerDispatcher.kt"

# interfaces
.implements Lkotlinx/coroutines/internal/MainDispatcherFactory;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public createDispatcher(Ljava/util/List;)Lcom/daydreamer/wecatch/gd3;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "+",
            "Lkotlinx/coroutines/internal/MainDispatcherFactory;",
            ">;)",
            "Lcom/daydreamer/wecatch/gd3;"
        }
    .end annotation

    .line 2
    new-instance p1, Lcom/daydreamer/wecatch/gd3;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/daydreamer/wecatch/id3;->a(Landroid/os/Looper;Z)Landroid/os/Handler;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1, v0, v1, v2, v1}, Lcom/daydreamer/wecatch/gd3;-><init>(Landroid/os/Handler;Ljava/lang/String;ILcom/daydreamer/wecatch/e83;)V

    return-object p1
.end method

.method public bridge synthetic createDispatcher(Ljava/util/List;)Lcom/daydreamer/wecatch/uc3;
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Lkotlinx/coroutines/android/AndroidDispatcherFactory;->createDispatcher(Ljava/util/List;)Lcom/daydreamer/wecatch/gd3;

    move-result-object p1

    return-object p1
.end method

.method public getLoadPriority()I
    .registers 2

    const v0, 0x3fffffff    # 1.9999999f

    return v0
.end method

.method public hintOnError()Ljava/lang/String;
    .registers 2

    const-string v0, "For tests Dispatchers.setMain from kotlinx-coroutines-test module can be used"

    return-object v0
.end method
