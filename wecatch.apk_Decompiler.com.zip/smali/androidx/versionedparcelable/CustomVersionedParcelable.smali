###### Class androidx.versionedparcelable.CustomVersionedParcelable (androidx.versionedparcelable.CustomVersionedParcelable)
.class public abstract Landroidx/versionedparcelable/CustomVersionedParcelable;
.super Ljava/lang/Object;
.source "CustomVersionedParcelable.java"

# interfaces
.implements Lcom/daydreamer/wecatch/tn;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
