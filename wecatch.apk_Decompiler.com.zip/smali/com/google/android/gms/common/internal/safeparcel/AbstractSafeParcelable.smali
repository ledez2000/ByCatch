###### Class com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable (com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable)
.class public abstract Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-basement@@18.0.0"

# interfaces
.implements Lcom/google/android/gms/common/internal/safeparcel/SafeParcelable;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final describeContents()I
    .registers 2

    const/4 v0, 0x0

    return v0
.end method
