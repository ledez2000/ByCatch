###### Class com.google.android.gms.internal.gtm.zzcr (com.google.android.gms.internal.gtm.zzcr)
.class public interface abstract Lcom/google/android/gms/internal/gtm/zzcr;
.super Ljava/lang/Object;
.source "com.google.android.gms:play-services-analytics-impl@@17.0.1"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<U::",
        "Lcom/google/android/gms/internal/gtm/zzcq;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract zza()Lcom/google/android/gms/internal/gtm/zzcq;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TU;"
        }
    .end annotation
.end method

.method public abstract zzb(Ljava/lang/String;Ljava/lang/String;)V
.end method

.method public abstract zzc(Ljava/lang/String;Z)V
.end method

.method public abstract zzd(Ljava/lang/String;I)V
.end method

.method public abstract zze(Ljava/lang/String;Ljava/lang/String;)V
.end method
