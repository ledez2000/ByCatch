###### Class com.google.android.gms.internal.gtm.zzyh (com.google.android.gms.internal.gtm.zzyh)
.class public Lcom/google/android/gms/internal/gtm/zzyh;
.super Lcom/google/android/gms/internal/gtm/zzur;
.source "com.google.android.gms:play-services-analytics-impl@@17.0.1"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/google/android/gms/internal/gtm/zzur;-><init>()V

    return-void
.end method


# virtual methods
.method public final zza()Lcom/google/android/gms/internal/gtm/zzuj;
    .registers 3

    .line 1
    new-instance v0, Lcom/google/android/gms/internal/gtm/zzyi;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/google/android/gms/internal/gtm/zzyi;-><init>(Lcom/google/android/gms/internal/gtm/zzyg;)V

    return-object v0
.end method
