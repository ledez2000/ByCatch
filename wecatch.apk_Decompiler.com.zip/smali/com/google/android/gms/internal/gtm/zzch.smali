###### Class com.google.android.gms.internal.gtm.zzch (com.google.android.gms.internal.gtm.zzch)
.class public final Lcom/google/android/gms/internal/gtm/zzch;
.super Lcom/google/android/gms/internal/gtm/zzcw;
.source "com.google.android.gms:play-services-analytics-impl@@17.0.1"


# instance fields
.field public final synthetic zza:Lcom/google/android/gms/internal/gtm/zzck;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/internal/gtm/zzck;Lcom/google/android/gms/internal/gtm/zzbv;)V
    .registers 3

    iput-object p1, p0, Lcom/google/android/gms/internal/gtm/zzch;->zza:Lcom/google/android/gms/internal/gtm/zzck;

    .line 1
    invoke-direct {p0, p2}, Lcom/google/android/gms/internal/gtm/zzcw;-><init>(Lcom/google/android/gms/internal/gtm/zzbv;)V

    return-void
.end method


# virtual methods
.method public final zza()V
    .registers 2

    iget-object v0, p0, Lcom/google/android/gms/internal/gtm/zzch;->zza:Lcom/google/android/gms/internal/gtm/zzck;

    .line 1
    invoke-static {v0}, Lcom/google/android/gms/internal/gtm/zzck;->zzc(Lcom/google/android/gms/internal/gtm/zzck;)V

    return-void
.end method
