###### Class com.google.android.gms.maps.model.ButtCap (com.google.android.gms.maps.model.ButtCap)
.class public final Lcom/google/android/gms/maps/model/ButtCap;
.super Lcom/google/android/gms/maps/model/Cap;
.source "com.google.android.gms:play-services-maps@@18.0.0"


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x0

    .line 1
    invoke-direct {p0, v0}, Lcom/google/android/gms/maps/model/Cap;-><init>(I)V

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 2

    const-string v0, "[ButtCap]"

    return-object v0
.end method
